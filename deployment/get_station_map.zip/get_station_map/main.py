# backend/lambdas/get_station_map/main.py
import json
import logging
import pandas as pd
from sqlalchemy import text
from shared.database import engine
from pyproj import Transformer

logging.basicConfig(level=logging.INFO)

def fetch_station_locations():
    try:
        query = text("""
            SELECT DISTINCT "Station", 
                   (locations::point)[0] AS latitude, 
                   (locations::point)[1] AS longitude
            FROM "Locations" 
            WHERE locations IS NOT NULL
        """)
        with engine.connect() as connection:
            result = connection.execute(query)
            df = pd.DataFrame(result.fetchall(), columns=result.keys())

        if df.empty:
            logging.warning("No station location data fetched for map")
            return pd.DataFrame(columns=["Station", "longitude", "latitude"])

        df['latitude'] = df['latitude'].astype(str).str.replace("(", "", regex=False).str.replace(")", "", regex=False).astype(float)
        df['longitude'] = df['longitude'].astype(str).str.replace("(", "", regex=False).str.replace(")", "", regex=False).astype(float)
        return df
    except Exception as e:
        logging.error(f"Error fetching locations: {e}")
        return pd.DataFrame(columns=["Station", "longitude", "latitude"])

def handler(event, context):
    try:
        locations_df = fetch_station_locations()
        if locations_df.empty:
            return {
                "statusCode": 404,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"message": "No station location data available"})
            }

        transformer = Transformer.from_crs("epsg:4326", "epsg:2039", always_xy=True)
        locations_df[['x', 'y']] = locations_df.apply(
            lambda row: pd.Series(transformer.transform(row['longitude'], row['latitude'])),
            axis=1
        )

        locations_df = locations_df.dropna(subset=['x', 'y'])
        locations_df = locations_df.sort_values(by='Station')

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps(locations_df[['Station', 'x', 'y']].to_dict(orient='records'))
        }
    except Exception as e:
        logging.error(f"Error in get_station_map lambda: {e}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error"})
        }