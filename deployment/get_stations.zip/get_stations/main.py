# backend/lambdas/get_stations/main.py
import json
import logging
from shared.database import engine, L
from sqlalchemy import select

logging.basicConfig(level=logging.INFO)

def get_all_stations_from_db():
    try:
        with engine.connect() as connection:
            query = select(L.c.Station).distinct().order_by(L.c.Station)
            result = connection.execute(query)
            stations = [row[0] for row in result if row[0] is not None]
            return ['All Stations'] + stations
    except Exception as e:
        logging.error(f"Error fetching stations: {e}")
        return []

def handler(event, context):
    try:
        stations = get_all_stations_from_db()
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"stations": stations})
        }
    except Exception as e:
        logging.error(f"Error in get_stations lambda: {e}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error"})
        }