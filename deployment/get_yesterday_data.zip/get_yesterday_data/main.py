# backend/lambdas/get_yesterday_data/main.py
import json
import logging
from datetime import datetime, timedelta
from shared.data_processing import load_data_from_db

logging.basicConfig(level=logging.INFO)

def handler(event, context):
    try:
        path_params = event.get('pathParameters') or {}
        station = path_params.get('station')
        if not station:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": "Station parameter is required"})
            }

        today = datetime.utcnow().date()
        yesterday = today - timedelta(days=1)
        start_date = datetime.combine(yesterday, datetime.min.time()).strftime('%Y-%m-%d %H:%M:%S')
        end_date = datetime.combine(yesterday, datetime.max.time()).strftime('%Y-%m-%d %H:%M:%S')

        df = load_data_from_db(start_date=start_date, end_date=end_date, station=station, data_source='default')
        response_body = df.to_json(orient='records', date_format='iso')

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": response_body
        }
    except Exception as e:
        logging.error(f"Error in get_yesterday_data lambda: {e}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error"})
        }