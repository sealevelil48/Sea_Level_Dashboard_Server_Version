# backend/lambdas/get_live_data/main.py
import json
import logging
from sqlalchemy import select, func, and_
from shared.database import engine, M, L

logging.basicConfig(level=logging.INFO)

def handler(event, context):
    try:
        path_params = event.get('pathParameters') or {}
        station = path_params.get('station')

        latest_time_subq = (
            select([
                L.c.Station,
                func.max(M.c.Tab_DateTime).label('max_time')
            ])
            .select_from(M.join(L, M.c.Tab_TabularTag == L.c.Tab_TabularTag))
            .group_by(L.c.Station)
            .subquery()
        )

        stmt = (
            select([
                L.c.Station,
                M.c.Tab_Value_mDepthC1,
                M.c.Tab_DateTime
            ])
            .select_from(
                M.join(L, M.c.Tab_TabularTag == L.c.Tab_TabularTag)
                .join(latest_time_subq, and_(
                    L.c.Station == latest_time_subq.c.Station,
                    M.c.Tab_DateTime == latest_time_subq.c.max_time
                ))
            )
        )

        if station:
            stmt = stmt.where(L.c.Station == station)

        with engine.connect() as conn:
            result = conn.execute(stmt)
            columns = result.keys()
            rows = result.fetchall()

        data = [dict(zip(columns, row)) for row in rows]
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"station": station or 'all', "data": data})
        }
    except Exception as e:
        logging.error(f"Error in get_live_data lambda: {e}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error"})
        }