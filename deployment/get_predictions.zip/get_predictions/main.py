# backend/lambdas/get_predictions/main.py
import json
import logging
from shared.data_processing import arima_predict, prophet_predict

logging.basicConfig(level=logging.INFO)

def handler(event, context):
    try:
        params = event.get('queryStringParameters') or {}
        station = params.get('station')
        model = params.get('model', 'all')

        if not station:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": "Station parameter is required"})
            }

        results = {}
        if model in ['arima', 'all']:
            arima_pred = arima_predict(station)
            results['arima'] = arima_pred if arima_pred else None

        if model in ['prophet', 'all']:
            prophet_pred = prophet_predict(station)
            if prophet_pred is not None and not prophet_pred.empty:
                results['prophet'] = prophet_pred.to_dict(orient='records')
            else:
                results['prophet'] = None

        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps(results)
        }
    except Exception as e:
        logging.error(f"Error in get_predictions lambda: {e}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error"})
        }