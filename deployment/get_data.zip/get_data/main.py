# backend/lambdas/get_data/main.py
import json
import logging
from shared.data_processing import load_data_from_db, detect_anomalies

logging.basicConfig(level=logging.INFO)

def handler(event, context):
    try:
        params = event.get('queryStringParameters') or {}
        station = params.get('station', 'All Stations')
        start_date = params.get('start_date')
        end_date = params.get('end_date')
        data_source = params.get('data_source', 'default')
        show_anomalies = params.get('show_anomalies', 'false').lower() == 'true'

        if station == 'All Stations':
            station = None

        if data_source == 'default' and not station:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({"error": "Station parameter is required for default data source"})
            }

        df = load_data_from_db(start_date, end_date, station, data_source)

        if show_anomalies and data_source == 'default' and not df.empty:
            df = detect_anomalies(df.copy())
        else:
            if 'anomaly' not in df.columns:
                df['anomaly'] = 0

        if df.empty:
            return {
                "statusCode": 404,
                "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
                "body": json.dumps({
                    "message": "No data found",
                    "details": {
                        "station": station or "All Stations",
                        "start_date": start_date,
                        "end_date": end_date,
                        "data_source": data_source
                    }
                })
            }

        response_body = df.to_json(orient='records', date_format='iso')
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": response_body
        }
    except Exception as e:
        logging.error(f"Error in get_data lambda: {e}")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error"})
        }