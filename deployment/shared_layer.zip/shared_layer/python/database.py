# backend/shared/database.py
import os
import logging
from sqlalchemy import create_engine, MetaData, Table, Column
from sqlalchemy.types import TypeDecorator, String
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Database URI from environment
DB_URI = os.getenv('DB_URI')
if not DB_URI:
    raise RuntimeError("DB_URI not set. Check environment variables.")

# Create SQLAlchemy engine
engine = create_engine(DB_URI, pool_pre_ping=True, pool_size=5, max_overflow=10, pool_recycle=1800)
metadata = MetaData()

# Custom TypeDecorator for PostgreSQL POINT type
class PointType(TypeDecorator):
    impl = String
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return f"{value[0]},{value[1]}" if value else None

    def process_result_value(self, value, dialect):
        return tuple(map(float, value.split(','))) if value else None

# Define database tables
try:
    M = Table('Monitors_info2', metadata,
              Column('Tab_TabularTag', String),
              autoload_with=engine,
              extend_existing=True)
    
    L = Table('Locations', metadata,
              Column('locations', PointType()),
              Column('Station', String),
              autoload_with=engine,
              extend_existing=True)
    
    S = Table('SeaTides', metadata,
              autoload_with=engine,
              extend_existing=True)
    
    logging.info("Database tables loaded successfully.")
except Exception as e:
    logging.error(f"Database initialization failed: {e}")
    M, L, S = None, None, None