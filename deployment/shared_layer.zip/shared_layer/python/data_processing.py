# backend/shared/data_processing.py
import pandas as pd
import numpy as np
from sqlalchemy import select, and_, text, func
from datetime import datetime, timedelta
from statsmodels.tsa.arima.model import ARIMA
from prophet import Prophet
from sklearn.ensemble import IsolationForest
from .database import engine, M, L, S

# Data Loading
def load_data_from_db(start_date=None, end_date=None, station=None, data_source='default'):
    if engine is None or M is None or L is None or S is None:
        logging.error("Database engine or tables not loaded. Cannot query data.")
        return pd.DataFrame()

    try:
        sql_query_obj = build_query(start_date, end_date, station, data_source)
        if sql_query_obj is None:
            logging.error("build_query returned None. Cannot execute query.")
            return pd.DataFrame()

        df_chunks = []
        with engine.connect() as connection:
            result = connection.execute(sql_query_obj)
            while True:
                chunk = result.fetchmany(10000)
                if not chunk:
                    break
                df_chunk = pd.DataFrame(chunk, columns=result.keys())
                df_chunks.append(df_chunk)

        if not df_chunks:
            return pd.DataFrame()
        return pd.concat(df_chunks, ignore_index=True)

    except Exception as e:
        logging.error(f"Data load error: {e}")
        return pd.DataFrame()

def build_query(start_date, end_date, station, data_source):
    params = {}
    if start_date:
        params['start_date'] = start_date
    if end_date:
        params['end_date'] = end_date
    if station and station != 'All Stations':
        params['station'] = station

    stmt = None
    table_for_date_filter = None
    date_col_name = None

    if data_source == 'tides':
        cols_to_select = tides_columns()
        table_for_date_filter = S
        date_col_name = 'Date'
        stmt = select(*cols_to_select).select_from(S)
    else:
        cols_to_select = default_columns()
        join_condition = M.c.Tab_TabularTag == L.c.Tab_TabularTag
        stmt = select(*cols_to_select).select_from(M.join(L, join_condition))
        table_for_date_filter = M
        date_col_name = 'Tab_DateTime'

    if start_date:
        stmt = stmt.where(table_for_date_filter.c[date_col_name] >= params['start_date'])
    if end_date:
        stmt = stmt.where(table_for_date_filter.c[date_col_name] <= params['end_date'])

    if data_source == 'default' and 'station' in params:
        stmt = stmt.where(L.c.Station == params['station'])
    elif data_source == 'tides' and 'station' in params:
        stmt = stmt.where(S.c.Station == params['station'])

    if date_col_name and table_for_date_filter is not None:
        stmt = stmt.order_by(table_for_date_filter.c[date_col_name])

    return stmt

def default_columns():
    return [M.c.Tab_DateTime, L.c.Station, M.c.Tab_Value_mDepthC1, M.c.Tab_Value_monT2m]

def tides_columns():
    return [S.c.Date, S.c.Station, S.c.HighTide, S.c.High_', S.c.LowTideTime, S.c.LowTideTemp, S.c.MeasurementCount]

# Prediction Functions
def get_prediction_data(station):
    end_date = datetime.now()
    start_date = end_date - timedelta(days=365)
    return load_data_from_db(
        start_date=start_date.strftime('%Y-%m-%d'),
        end_date=end_date.strftime('%Y-%m-%d'),
        station=station,
        data_source='default'
    )

def arima_predict(station):
    try:
        df = get_prediction_data(station)
        if df.empty or 'Tab_Value_mDepthC1' not in df.columns:
            logging.warning(f"No data available for ARIMA prediction for station {station}.")
            return None

        df['Tab_DateTime'] = pd.to_datetime(df['Tab_DateTime'])
        df = df.sort_values('Tab_DateTime')
        df = df.set_index('Tab_DateTime')

        series_to_predict = df['Tab_Value_mDepthC1'].resample('h').mean().dropna()
        if len(series_to_predict) < 20:
            logging.warning(f"Not enough data points ({len(series_to_predict)}) for ARIMA prediction for station {station}.")
            return None

        model = ARIMA(series_to_predict, order=(5, 1, 0))
        model_fit = model.fit()
        forecast = model_fit.forecast(steps=240)
        return forecast.tolist()
    except Exception as e:
        logging.error(f"ARIMA prediction failed for station {station}: {str(e)}")
        return None

def prophet_predict(station):
    try:
        df = get_prediction_data(station)
        if df.empty or 'Tab_Value_mDepthC1' not in df.columns:
            logging.warning(f"No data available for Prophet prediction for station {station}.")
            return pd.DataFrame()

        df['Tab_DateTime'] = pd.to_datetime(df['Tab_DateTime'])
        df = df.sort_values('Tab_DateTime')
        df = df.set_index('Tab_DateTime')

        prophet_df = df['Tab_Value_mDepthC1'].resample('h').mean().reset_index()
        prophet_df = prophet_df.rename(columns={'Tab_DateTime': 'ds', 'Tab_Value_mDepthC1': 'y'})[['ds', 'y']].dropna()

        if len(prophet_df) < 50:
            logging.warning(f"Not enough data points ({len(prophet_df)}) for Prophet prediction for station {station}.")
            return pd.DataFrame()

        model = Prophet(yearly_seasonality=True, daily_seasonality=True, growth='linear')
        model.fit(prophet_df)
        future = model.make_future_dataframe(periods=240, freq='h')

        if future.empty:
            logging.warning(f"Future dataframe is empty for station {station}.")
            return pd.DataFrame()

        forecast = model.predict(future)
        if forecast is None or forecast.empty or 'yhat' not in forecast.columns:
            logging.warning(f"Forecast result is invalid for station {station}.")
            return pd.DataFrame()

        return forecast[['ds', 'yhat']]
    except Exception as e:
        logging.error(f"Prophet prediction failed for station {station}: {str(e)}")
        return pd.DataFrame()

# Anomaly Detection
def detect_anomalies(df):
    iso_forest = IsolationForest(contamination=0.01, random_state=42)
    if df.empty or 'Tab_Value_mDepthC1' not in df.columns:
        return df

    X = df[['Tab_Value_mDepthC1']].values
    pred = iso_forest.fit_predict(X)
    df['anomaly'] = np.where(pred == -1, -1, 0)
    return df

# Stats Calculation
def calculate_stats(df):
    stats = {
        'current_level': None,
        '24h_change': None,
        'avg_temp': None,
        'anomalies': None
    }

    if not df.empty:
        try:
            if 'Tab_Value_mDepthC1' in df.columns:
                stats['current_level'] = df['Tab_Value_mDepthC1'].iloc[-1]

            if 'Tab_Value_mDepthC1' in df.columns and len(df) > 1:
                now_val = df['Tab_Value_mDepthC1'].iloc[-1]
                yesterday_val = df['Tab_Value_mDepthC1'].iloc[0]
                stats['24h_change'] = now_val - yesterday_val

            if 'Tab_Value_monT2m' in df.columns:
                stats['avg_temp'] = df['Tab_Value_monT2m'].mean()

            if 'anomaly' in df.columns:
                stats['anomalies'] = df[df['anomaly'] == -1].shape[0]
        except Exception as e:
            logging.error(f"Error calculating stats: {e}")

    return stats